import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, Check, X, CalendarPlus, Clock, Star, Users, UserCheck, Ban, Copy, BarChart3, Pencil, Trash2, Ticket } from "lucide-react";
import { supabase } from "../lib/supabaseClient";
import { colors, fonts } from "../lib/theme";
import InviteButtons from "../components/InviteButtons.jsx";
import AdminVenues from "../components/AdminVenues.jsx";
import AdminMembers from "../components/AdminMembers.jsx";
import PasswordInput from "../components/PasswordInput.jsx";
import AdminAddRegistration from "../components/AdminAddRegistration.jsx";
import AdminExternalImports from "../components/AdminExternalImports.jsx";
import AdminReviewTools from "../components/AdminReviewTools.jsx";
import AdminEventExtras from "../components/AdminEventExtras.jsx";
import AdminUpdates from "../components/AdminUpdates.jsx";
import { eventInviteUrl } from "../lib/invite";
import { useIsDesktop } from "../lib/useIsDesktop";
import AdminDesktopShell, { AdminDashboard } from "../components/AdminDesktopShell.jsx";

export default function Admin() {
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [loadingRequests, setLoadingRequests] = useState(false);
  const [requestsError, setRequestsError] = useState("");
  const [moderatingRequest, setModeratingRequest] = useState(null);
  const [pendingEvents, setPendingEvents] = useState([]);
  const [adminSecret, setAdminSecret] = useState("");
  const isDesktop = useIsDesktop();
  const [section, setSection] = useState("accueil");
  const [moderating, setModerating] = useState(null);
  const [modError, setModError] = useState("");

  const [members, setMembers] = useState(null);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [membersError, setMembersError] = useState("");
  const [togglingId, setTogglingId] = useState(null);

  const [allEvents, setAllEvents] = useState([]);
  const [selectedEventId, setSelectedEventId] = useState("");
  const [guestState, setGuestState] = useState(null);
  const [loadingGuests, setLoadingGuests] = useState(false);
  const [guestsError, setGuestsError] = useState("");
  const [guestToggling, setGuestToggling] = useState(null);

  const [duplicateDate, setDuplicateDate] = useState("");
  const [duplicating, setDuplicating] = useState(false);
  const [duplicateMsg, setDuplicateMsg] = useState("");

  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteMsg, setDeleteMsg] = useState("");

  const [venueStats, setVenueStats] = useState(null);
  const [loadingVenueStats, setLoadingVenueStats] = useState(false);
  const [venueStatsError, setVenueStatsError] = useState("");

  const [adminVerified, setAdminVerified] = useState(null);
  const [eventTickets, setEventTickets] = useState(null);
  const [loadingTickets, setLoadingTickets] = useState(false);
  const [ticketsError, setTicketsError] = useState("");
  const [ticketSearch, setTicketSearch] = useState("");
  const [ticketExtras, setTicketExtras] = useState(null);
  const [verifying, setVerifying] = useState(false);
  const [inviteLink, setInviteLink] = useState(null);
  const [loadingInviteLink, setLoadingInviteLink] = useState(false);

  useEffect(() => {
    async function loadPending() {
      if (!import.meta.env.VITE_SUPABASE_URL) return;
      const { data } = await supabase.from("events").select("*").eq("approved", false);
      if (data) setPendingEvents(data);
    }
    loadPending();

    async function loadAllEvents() {
      if (!import.meta.env.VITE_SUPABASE_URL) return;
      const { data } = await supabase.from("events").select("id, title, event_date, visibility, is_free, seats, taken, venue_id, approved").order("event_date", { ascending: false }).limit(50);
      if (data) setAllEvents(data);
    }
    loadAllEvents();
  }, []);

  // Si l'événement a été choisi avant de valider le mot de passe, on charge les inscriptions
  // dès que le mot de passe est validé (plus besoin de rechoisir l'événement)
  useEffect(() => {
    if (adminVerified === true && selectedEventId && eventTickets === null && !loadingTickets) {
      loadGuests(selectedEventId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [adminVerified]);

  async function handleVerifyAdmin(e) {
    if (e) e.preventDefault();
    if (!adminSecret) {
      setAdminVerified(false);
      return;
    }
    setVerifying(true);
    setAdminVerified(null);
    try {
      const res = await fetch("/api/list-members", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret })
      });
      const data = await res.json();
      if (!res.ok) {
        setAdminVerified(false);
        setVerifying(false);
        return;
      }
      setMembers(data.profiles);
      setAdminVerified(true);
      setVerifying(false);
      loadCoRequests(adminSecret);
    } catch (err) {
      setAdminVerified(false);
      setVerifying(false);
    }
  }

  async function loadCoRequests(secret) {
    setLoadingRequests(true);
    setRequestsError("");
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret: secret, action: "co-requests-list" })
      });
      const data = await res.json();
      if (!res.ok) {
        setRequestsError(data.error || "Erreur");
        setLoadingRequests(false);
        return;
      }
      setRequests(data.requests || []);
      setLoadingRequests(false);
    } catch (err) {
      setRequestsError("Impossible de contacter le serveur");
      setLoadingRequests(false);
    }
  }

  async function moderateRequest(requestId, decision) {
    setModeratingRequest(requestId);
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "co-request-moderate", requestId, decision })
      });
      if (res.ok) {
        setRequests((prev) => prev.filter((r) => r.id !== requestId));
      }
      setModeratingRequest(null);
    } catch (err) {
      setModeratingRequest(null);
    }
  }

  async function moderate(eventId, action) {
    if (!adminSecret) {
      setModError("Renseigne le mot de passe administrateur d'abord");
      return;
    }
    setModerating(eventId);
    setModError("");
    try {
      const res = await fetch("/api/moderate-event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, eventId, action })
      });
      const data = await res.json();
      if (!res.ok) {
        setModError(data.error || "Erreur");
        setModerating(null);
        return;
      }
      setPendingEvents((prev) => prev.filter((e) => e.id !== eventId));
      setModerating(null);
    } catch (err) {
      setModError("Impossible de contacter le serveur");
      setModerating(null);
    }
  }

  async function loadMembers() {
    if (!adminSecret) {
      setMembersError("Renseigne le mot de passe administrateur d'abord");
      return;
    }
    setLoadingMembers(true);
    setMembersError("");
    try {
      const res = await fetch("/api/list-members", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret })
      });
      const data = await res.json();
      if (!res.ok) {
        setMembersError(data.error || "Erreur");
        setLoadingMembers(false);
        return;
      }
      setMembers(data.profiles);
      setLoadingMembers(false);
    } catch (err) {
      setMembersError("Impossible de contacter le serveur");
      setLoadingMembers(false);
    }
  }

  async function toggleMember(profileId, current) {
    setTogglingId(profileId);
    try {
      const res = await fetch("/api/set-member-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, profileId, isMember: !current })
      });
      if (res.ok) {
        setMembers((prev) => prev.map((m) => (m.id === profileId ? { ...m, is_member: !current } : m)));
      }
      setTogglingId(null);
    } catch (err) {
      setTogglingId(null);
    }
  }

  async function loadGuests(eventId) {
    setSelectedEventId(eventId);
    setGuestState(null);
    setGuestsError("");
    setDuplicateMsg("");
    setDuplicateDate("");
    setConfirmingDelete(false);
    setDeleteMsg("");
    setEventTickets(null);
    setTicketExtras(null);
    setTicketsError("");
    setTicketSearch("");
    setInviteLink(null);
    if (!eventId) return;
    if (!adminSecret) {
      setGuestsError("Renseigne le mot de passe administrateur d'abord");
      return;
    }
    // Les inscriptions s'affichent directement dès qu'on choisit l'événement
    loadTickets(eventId);
    if (!members) {
      await loadMembers();
    }
    setLoadingGuests(true);
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "list", eventId })
      });
      const data = await res.json();
      if (!res.ok) {
        setGuestsError(data.error || "Erreur");
        setLoadingGuests(false);
        return;
      }
      setGuestState({ invited: data.invited || [], blocked: data.blocked || [] });
      setLoadingGuests(false);
    } catch (err) {
      setGuestsError("Impossible de contacter le serveur");
      setLoadingGuests(false);
    }
  }

  async function loadInviteLink() {
    setLoadingInviteLink(true);
    setGuestsError("");
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "invite-link", eventId: selectedEventId })
      });
      const data = await res.json();
      if (!res.ok) {
        setGuestsError(data.error || "Impossible de générer le lien d'invitation");
      } else {
        setInviteLink(eventInviteUrl(selectedEventId, data.token));
      }
    } catch (err) {
      setGuestsError("Impossible de contacter le serveur");
    }
    setLoadingInviteLink(false);
  }

  async function toggleGuestAction(action, userId, currentlyOn) {
    setGuestToggling(userId + action);
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action, eventId: selectedEventId, userId, value: !currentlyOn })
      });
      if (res.ok) {
        setGuestState((prev) => {
          const key = action === "set-invite" ? "invited" : "blocked";
          const list = prev[key];
          const next = currentlyOn ? list.filter((id) => id !== userId) : [...list, userId];
          return { ...prev, [key]: next };
        });
      }
      setGuestToggling(null);
    } catch (err) {
      setGuestToggling(null);
    }
  }

  async function handleDuplicate() {
    if (!adminSecret) {
      setDuplicateMsg("Renseigne le mot de passe administrateur d'abord");
      return;
    }
    if (!duplicateDate) {
      setDuplicateMsg("Choisis une date pour la copie");
      return;
    }
    setDuplicating(true);
    setDuplicateMsg("");
    try {
      const res = await fetch("/api/create-event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "duplicate", eventId: selectedEventId, newDate: duplicateDate })
      });
      const data = await res.json();
      if (!res.ok) {
        setDuplicateMsg(data.error || "Erreur lors de la duplication");
        setDuplicating(false);
        return;
      }
      setDuplicateMsg("Événement dupliqué avec succès !");
      setDuplicateDate("");
      setDuplicating(false);
    } catch (err) {
      setDuplicateMsg("Impossible de contacter le serveur");
      setDuplicating(false);
    }
  }

  async function handleDelete() {
    if (!adminSecret) {
      setDeleteMsg("Renseigne le mot de passe administrateur d'abord");
      return;
    }
    if (!confirmingDelete) {
      setConfirmingDelete(true);
      return;
    }
    setDeleting(true);
    setDeleteMsg("");
    try {
      const res = await fetch("/api/create-event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "delete", eventId: selectedEventId })
      });
      const data = await res.json();
      if (!res.ok) {
        setDeleteMsg(data.error || "Erreur lors de la suppression");
        setDeleting(false);
        setConfirmingDelete(false);
        return;
      }
      setAllEvents((prev) => prev.filter((e) => e.id !== selectedEventId));
      setSelectedEventId("");
      setGuestState(null);
      setDeleting(false);
      setConfirmingDelete(false);
      setDeleteMsg("Événement supprimé.");
    } catch (err) {
      setDeleteMsg("Impossible de contacter le serveur");
      setDeleting(false);
      setConfirmingDelete(false);
    }
  }

  async function loadTickets(eventIdOverride) {
    const evId = typeof eventIdOverride === "string" ? eventIdOverride : selectedEventId;
    if (!evId) return;
    if (!adminSecret) {
      setTicketsError("Renseigne le mot de passe administrateur d'abord");
      return;
    }
    setLoadingTickets(true);
    setTicketsError("");
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "tickets", eventId: evId })
      });
      const data = await res.json();
      if (!res.ok) {
        setTicketsError(data.error || "Erreur");
        setLoadingTickets(false);
        return;
      }
      setEventTickets(data.tickets || []);
      setTicketExtras({ waitlist: data.waitlist || [], ratings: data.ratings || null, contacts: data.contacts || [] });
      setLoadingTickets(false);
    } catch (err) {
      setTicketsError("Impossible de contacter le serveur");
      setLoadingTickets(false);
    }
  }

  async function sendTicket(t) {
    let email = "";
    if (!t.hasEmail) {
      email = (window.prompt(`Email de ${t.name} pour lui envoyer son billet :`) || "").trim();
      if (!email) return;
    }
    setTicketsError("");
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "send-ticket", registrationId: t.id, email })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setTicketsError(data.error || "Envoi impossible");
        return;
      }
      setEventTickets((prev) => prev.map((x) => (x.id === t.id ? { ...x, emailed: true, hasEmail: true } : x)));
    } catch (err) {
      setTicketsError("Impossible de contacter le serveur");
    }
  }

  async function cancelTicket(t) {
    if (!window.confirm(`Annuler l'inscription de ${t.name}${(t.quantity || 1) > 1 ? ` (${t.quantity} personnes)` : ""} ? Les places seront libérées.`)) return;
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "cancel-registration", registrationId: t.id })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setTicketsError(data.error || "Annulation impossible");
        return;
      }
      setEventTickets((prev) => prev.filter((x) => x.id !== t.id));
    } catch (err) {
      setTicketsError("Impossible de contacter le serveur");
    }
  }

  async function toggleTicketPaid(t) {
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "mark-paid", registrationId: t.id, value: !t.paid })
      });
      if (res.ok) {
        setEventTickets((prev) => prev.map((x) => (x.id === t.id ? { ...x, paid: !t.paid } : x)));
      }
    } catch (err) {
      setTicketsError("Impossible de contacter le serveur");
    }
  }

  async function loadVenueStats() {
    if (!adminSecret) {
      setVenueStatsError("Renseigne le mot de passe administrateur d'abord");
      return;
    }
    setLoadingVenueStats(true);
    setVenueStatsError("");
    try {
      const res = await fetch("/api/manage-guests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminSecret, action: "venue-stats" })
      });
      const data = await res.json();
      if (!res.ok) {
        setVenueStatsError(data.error || "Erreur");
        setLoadingVenueStats(false);
        return;
      }
      setVenueStats(data.stats);
      setLoadingVenueStats(false);
    } catch (err) {
      setVenueStatsError("Impossible de contacter le serveur");
      setLoadingVenueStats(false);
    }
  }

  const show = (key) => !isDesktop || section === key;
  const controls = (
    <>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "18px 0 16px" }}>
        <button onClick={() => navigate("/")} style={{ background: "none", border: "none", color: colors.ink, cursor: "pointer" }}>
          <ChevronLeft size={22} />
        </button>
        <h1 style={{ fontFamily: fonts.display, fontSize: 20, margin: 0 }}>Espace administrateur</h1>
      </div>

      <button
        onClick={() => navigate("/admin/create-event")}
        style={{
          width: "100%",
          background: colors.orange,
          color: "#fff",
          border: "none",
          borderRadius: 14,
          padding: 13,
          fontWeight: 700,
          fontSize: 14,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 8,
          marginBottom: 20,
          boxShadow: "0 4px 12px rgba(232,95,38,0.3)"
        }}
      >
        <CalendarPlus size={16} /> Créer un événement payant
      </button>

      <label style={{ fontSize: 12, color: colors.muted, marginBottom: 5, display: "block" }}>
        Mot de passe administrateur (pour les actions ci-dessous)
      </label>
      <form onSubmit={handleVerifyAdmin} style={{ display: "flex", gap: 8, marginBottom: 8 }}>
        <PasswordInput
          wrapperStyle={{ flex: 1, minWidth: 0 }}
          placeholder="Mot de passe administrateur"
          value={adminSecret}
          onChange={(e) => {
            setAdminSecret(e.target.value);
            setAdminVerified(null);
          }}
          style={{
            flex: 1,
            minWidth: 0,
            background: colors.surface,
            border: `1px solid ${colors.border}`,
            borderRadius: 12,
            padding: "10px 12px",
            color: colors.ink,
            fontSize: 13.5,
            boxSizing: "border-box"
          }}
        />
        <button
          type="submit"
          disabled={verifying}
          style={{
            background: colors.orange,
            border: "none",
            color: "#fff",
            borderRadius: 12,
            padding: "0 16px",
            fontSize: 13,
            fontWeight: 700,
            cursor: "pointer",
            whiteSpace: "nowrap"
          }}
        >
          {verifying ? "…" : "Valider"}
        </button>
      </form>
      {adminVerified === true && (
        <p style={{ fontSize: 12, color: colors.olive, marginBottom: 28, fontWeight: 600 }}>
          <Check size={13} style={{ verticalAlign: "middle", marginRight: 4 }} />
          Mot de passe correct — tu peux utiliser les actions ci-dessous.
        </p>
      )}
      {adminVerified === false && (
        <p style={{ fontSize: 12, color: colors.red, marginBottom: 28, fontWeight: 600 }}>
          <X size={13} style={{ verticalAlign: "middle", marginRight: 4 }} />
          Mot de passe incorrect.
        </p>
      )}
      {adminVerified === null && <div style={{ marginBottom: 20 }} />}
    </>
  );
  const sections = (
    <>
{show("propositions") && (
<>
      {pendingEvents.length > 0 && (
        <div style={{ marginBottom: 28 }}>
          <h2 style={{ fontFamily: fonts.display, fontSize: 16, margin: "0 0 10px", display: "flex", alignItems: "center", gap: 6 }}>
            <Clock size={16} color={colors.orange} /> Propositions en attente
          </h2>
          {modError && <p style={{ color: colors.red, fontSize: 12, marginBottom: 10 }}>{modError}</p>}

          {pendingEvents.map((e) => (
            <div key={e.id} style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderRadius: 14, padding: 14, marginBottom: 12 }}>
              <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{e.title}</div>
              <div style={{ fontSize: 12, color: colors.muted, marginBottom: 2 }}>
                Par {e.organizer} — {e.organizer_contact}
                {e.organizer_id && members?.find((m) => m.id === e.organizer_id)?.is_ambassador && (
                  <span style={{ marginLeft: 6, fontWeight: 800, color: colors.navy }}>👑 Spritz Crew</span>
                )}
                {!e.is_free && !e.sumup_link && (
                  <span style={{ display: "block", color: colors.orange, fontWeight: 700 }}>
                    Paiement via ton SumUp (dans l'app) — à reverser au co-organisateur
                  </span>
                )}
              </div>
              <div style={{ fontSize: 12, color: colors.muted, marginBottom: 2 }}>
                {new Date(e.event_date).toLocaleString("fr-FR", { dateStyle: "medium", timeStyle: "short" })} — {e.address}
              </div>
              {e.is_free === false ? (
                <div style={{ fontSize: 12, color: colors.orange, fontWeight: 700, marginBottom: 4 }}>
                  Payant — {e.price_member}€ membre / {e.price_nonmember}€ non-membre
                </div>
              ) : (
                <div style={{ fontSize: 12, color: colors.olive, fontWeight: 700, marginBottom: 4 }}>Gratuit</div>
              )}
              {e.sumup_link && (
                <div style={{ fontSize: 11.5, color: colors.muted, marginBottom: 12, wordBreak: "break-all" }}>
                  Lien de paiement (organisateur) :{" "}
                  <a href={e.sumup_link} target="_blank" rel="noreferrer" style={{ color: colors.blue }}>
                    {e.sumup_link}
                  </a>
                </div>
              )}
              {!e.sumup_link && <div style={{ marginBottom: 12 }} />}
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  disabled={moderating === e.id}
                  onClick={() => moderate(e.id, "approve")}
                  style={{ flex: 1, background: colors.olive, border: "none", color: colors.ink, borderRadius: 10, padding: 8, fontWeight: 700, cursor: "pointer" }}
                >
                  <Check size={14} style={{ verticalAlign: "middle", marginRight: 6 }} /> Approuver
                </button>
                <button
                  disabled={moderating === e.id}
                  onClick={() => moderate(e.id, "reject")}
                  style={{ flex: 1, background: "none", border: `1px solid ${colors.border}`, color: colors.ink, borderRadius: 10, padding: 8, cursor: "pointer" }}
                >
                  <X size={14} style={{ verticalAlign: "middle", marginRight: 6 }} /> Refuser
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

</>
)}
{show("membres") && (
<>
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: fonts.display, fontSize: 16, margin: "0 0 10px", display: "flex", alignItems: "center", gap: 6 }}>
          <Users size={16} color={colors.orange} /> Membres &amp; Spritz Crew
        </h2>

        {members === null ? (
          <button
            onClick={loadMembers}
            disabled={loadingMembers}
            style={{
              width: "100%",
              background: "none",
              border: `1px solid ${colors.border}`,
              color: colors.ink,
              borderRadius: 12,
              padding: 12,
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer"
            }}
          >
            {loadingMembers ? "Chargement…" : "Afficher les membres (app installée, activité, ambassadeurs)"}
          </button>
        ) : (
          <AdminMembers
            members={members}
            setMembers={setMembers}
            adminSecret={adminSecret}
            onToggleMember={toggleMember}
            togglingId={togglingId}
          />
        )}
        {membersError && <p style={{ color: colors.red, fontSize: 12, marginTop: 8 }}>{membersError}</p>}
      </div>
</>
)}

{show("soirees") && (
<>
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: fonts.display, fontSize: 16, margin: "0 0 10px", display: "flex", alignItems: "center", gap: 6 }}>
          <UserCheck size={16} color={colors.orange} /> Gérer un événement : inscriptions, invités, duplication
        </h2>
        <select
          value={selectedEventId}
          onChange={(e) => loadGuests(e.target.value)}
          style={{
            width: "100%",
            background: colors.surface,
            border: `1px solid ${colors.border}`,
            borderRadius: 12,
            padding: "10px 12px",
            color: colors.ink,
            fontSize: 13.5,
            marginBottom: 14,
            boxSizing: "border-box"
          }}
        >
          <option value="">Choisir un événement…</option>
          {allEvents.map((e) => (
            <option key={e.id} value={e.id}>
              {e.title} — {new Date(e.event_date).toLocaleDateString("fr-FR")}
            </option>
          ))}
        </select>

        {selectedEventId && (
          <button
            onClick={() => navigate(`/admin/edit-event/${selectedEventId}`)}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
              background: "none",
              border: `1px solid ${colors.blue}`,
              color: colors.blue,
              borderRadius: 12,
              padding: 10,
              fontSize: 12.5,
              fontWeight: 700,
              cursor: "pointer",
              marginBottom: 14
            }}
          >
            <Pencil size={13} /> Modifier cet événement (corriger une erreur)
          </button>
        )}

        {selectedEventId && (
          <button
            onClick={() => navigate(`/event/${selectedEventId}/affichette`)}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
              background: "none",
              border: `1px solid ${colors.orange}`,
              color: colors.orange,
              borderRadius: 12,
              padding: 10,
              fontSize: 12.5,
              fontWeight: 700,
              cursor: "pointer",
              marginTop: -6,
              marginBottom: 14
            }}
          >
            🖼️ Affichette de l'événement (à imprimer ou à envoyer au lieu)
          </button>
        )}

        {selectedEventId &&
          (() => {
            const ev = allEvents.find((e) => e.id === selectedEventId);
            const isPrivate = ev?.visibility === "private";
            return inviteLink ? (
              <InviteButtons
                event={ev}
                url={inviteLink}
                title={isPrivate ? "Lien d'invitation privé" : "Inviter par WhatsApp / SMS"}
                subtitle={
                  isPrivate
                    ? "Toute personne qui ouvre ce lien et crée son compte est ajoutée aux invités. Ne le partage qu'avec les personnes voulues."
                    : undefined
                }
                style={{ marginBottom: 14 }}
              />
            ) : (
              <button
                onClick={loadInviteLink}
                disabled={loadingInviteLink}
                style={{
                  width: "100%",
                  background: "none",
                  border: "1px solid #25D366",
                  color: "#1a9e4b",
                  borderRadius: 12,
                  padding: 10,
                  fontSize: 12.5,
                  fontWeight: 700,
                  cursor: "pointer",
                  marginBottom: 14
                }}
              >
                {loadingInviteLink ? "Préparation…" : isPrivate ? "🔒 Lien d'invitation privé (WhatsApp / SMS)" : "Inviter par WhatsApp / SMS"}
              </button>
            );
          })()}

        {selectedEventId && <AdminReviewTools event={allEvents.find((e) => e.id === selectedEventId)} />}

        {selectedEventId && (
          <div
            style={{
              background: colors.surface,
              border: `1px solid ${colors.border}`,
              borderRadius: 12,
              padding: 12,
              marginBottom: 14
            }}
          >
            <div style={{ fontSize: 12.5, fontWeight: 700, marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}>
              <Ticket size={13} /> Inscriptions &amp; réservations (contrôle à l'entrée)
            </div>
            <AdminAddRegistration
              adminSecret={adminSecret}
              event={allEvents.find((e) => e.id === selectedEventId) || { id: selectedEventId }}
              onAdded={() => loadTickets(selectedEventId)}
            />
            {eventTickets === null ? (
              <button
                onClick={() => loadTickets()}
                disabled={loadingTickets}
                style={{
                  width: "100%",
                  background: "none",
                  border: `1px solid ${colors.border}`,
                  color: colors.ink,
                  borderRadius: 10,
                  padding: 9,
                  fontSize: 12.5,
                  fontWeight: 600,
                  cursor: "pointer"
                }}
              >
                {loadingTickets ? "Chargement…" : "Afficher les billets"}
              </button>
            ) : eventTickets.length === 0 ? (
              <p style={{ fontSize: 12, color: colors.muted, margin: 0 }}>
                Aucun billet ni réservation pour cet événement pour l'instant.
              </p>
            ) : (
              <>
                <input
                  placeholder="Rechercher un code ou un nom…"
                  value={ticketSearch}
                  onChange={(e) => setTicketSearch(e.target.value)}
                  style={{
                    width: "100%",
                    background: colors.bg,
                    border: `1px solid ${colors.border}`,
                    borderRadius: 10,
                    padding: "8px 10px",
                    fontSize: 12.5,
                    color: colors.ink,
                    boxSizing: "border-box",
                    marginBottom: 8
                  }}
                />
                {eventTickets
                  .filter((t) => {
                    const q = ticketSearch.trim().toLowerCase();
                    return (
                      !q ||
                      (t.code || "").toLowerCase().includes(q) ||
                      (t.name || "").toLowerCase().includes(q) ||
                      (t.attendeeNames || []).some((n) => n.toLowerCase().includes(q))
                    );
                  })
                  .map((t) => (
                    <div
                      key={t.id}
                      style={{ display: "flex", justifyContent: "space-between", gap: 8, padding: "7px 0", borderTop: `1px solid ${colors.border}`, fontSize: 12.5 }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 600 }}>
                          {t.name}
                          {t.firstTime && (
                            <span style={{ marginLeft: 6, background: colors.gold, color: colors.navy, borderRadius: 20, padding: "1px 7px", fontSize: 10.5, fontWeight: 800 }}>
                              1re fois
                            </span>
                          )}
                          {(t.quantity || 1) > 1 && (
                            <span
                              style={{ marginLeft: 6, background: colors.orange, color: "#fff", borderRadius: 20, padding: "1px 7px", fontSize: 10.5, fontWeight: 800 }}
                            >
                              ×{t.quantity}
                            </span>
                          )}
                        </div>
                        {t.attendeeNames?.length > 0 && (
                          <div style={{ color: colors.muted, fontSize: 11.5 }}>avec {t.attendeeNames.join(", ")}</div>
                        )}
                        {t.options.length > 0 && <div style={{ color: colors.muted, fontSize: 11.5 }}>+ {t.options.join(", ")}</div>}
                        {t.source && <div style={{ color: colors.muted, fontSize: 11 }}>via {t.source}</div>}
                        {t.withoutAccount && t.contact && (
                          <div style={{ color: colors.muted, fontSize: 11 }}>sans compte · {t.contact}</div>
                        )}
                      </div>
                      <div style={{ textAlign: "right", flexShrink: 0 }}>
                        <div style={{ fontFamily: "ui-monospace, Menlo, monospace", fontWeight: 800, letterSpacing: 1 }}>{t.code}</div>
                        <div style={{ color: colors.muted, fontSize: 11.5 }}>{Number(t.amount).toLocaleString("fr-FR")} €</div>
                        {t.external ? (
                          <button
                            onClick={() => toggleTicketPaid(t)}
                            style={{
                              marginTop: 4,
                              background: t.paid ? "rgba(107,124,79,0.15)" : "none",
                              border: `1px solid ${t.paid ? colors.olive : colors.gold}`,
                              color: t.paid ? colors.olive : "#9A6B00",
                              borderRadius: 20,
                              padding: "3px 9px",
                              fontSize: 11,
                              fontWeight: 700,
                              cursor: "pointer",
                              whiteSpace: "nowrap"
                            }}
                          >
                            {t.paid ? "✓ Payé" : "Réservé"}
                          </button>
                        ) : Number(t.amount) === 0 ? (
                          <div style={{ color: colors.olive, fontSize: 11, fontWeight: 700 }}>✓ Inscrit (gratuit)</div>
                        ) : (
                          <div style={{ color: colors.olive, fontSize: 11, fontWeight: 700 }}>✓ Payé en ligne</div>
                        )}
                        <button
                          onClick={() => sendTicket(t)}
                          style={{
                            display: "block",
                            marginLeft: "auto",
                            marginTop: 5,
                            background: t.emailed ? "rgba(107,124,79,0.12)" : "none",
                            border: `1px solid ${t.emailed ? colors.olive : colors.blue}`,
                            borderRadius: 20,
                            padding: "3px 9px",
                            color: t.emailed ? colors.olive : colors.blue,
                            fontSize: 11,
                            fontWeight: 700,
                            cursor: "pointer",
                            whiteSpace: "nowrap"
                          }}
                        >
                          {t.emailed ? "✓ Billet envoyé · renvoyer" : t.hasEmail ? "✉ Envoyer le billet" : "✉ Ajouter un email"}
                        </button>
                        <button
                          onClick={() => cancelTicket(t)}
                          style={{
                            display: "block",
                            marginLeft: "auto",
                            marginTop: 5,
                            background: "none",
                            border: `1px solid ${colors.red}`,
                            borderRadius: 20,
                            padding: "3px 9px",
                            color: colors.red,
                            fontSize: 11,
                            fontWeight: 700,
                            cursor: "pointer",
                            whiteSpace: "nowrap"
                          }}
                        >
                          ✕ Annuler
                        </button>
                      </div>
                    </div>
                  ))}
                <p style={{ fontSize: 11.5, color: colors.muted, margin: "8px 0 0" }}>
                  {eventTickets.length} réservation{eventTickets.length > 1 ? "s" : ""} ·{" "}
                  {eventTickets.reduce((n, t) => n + (t.quantity || 1), 0)} personne(s) ·{" "}
                  {eventTickets.filter((t) => t.paid).reduce((n, t) => n + (t.quantity || 1), 0)} confirmée(s)
                </p>
              </>
            )}
            {ticketsError && <p style={{ color: colors.red, fontSize: 12, marginTop: 6 }}>{ticketsError}</p>}
          </div>
        )}

        {selectedEventId && eventTickets && ticketExtras && (
          <AdminEventExtras event={allEvents.find((e) => e.id === selectedEventId)} tickets={eventTickets} extras={ticketExtras} />
        )}

        {selectedEventId && (
          <div style={{ marginBottom: 14 }}>
            <button
              onClick={handleDelete}
              disabled={deleting}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 6,
                background: confirmingDelete ? colors.red : "none",
                border: `1px solid ${colors.red}`,
                color: confirmingDelete ? "#fff" : colors.red,
                borderRadius: 12,
                padding: 10,
                fontSize: 12.5,
                fontWeight: 700,
                cursor: "pointer"
              }}
            >
              <Trash2 size={13} />
              {deleting ? "Suppression…" : confirmingDelete ? "Confirmer la suppression définitive" : "Supprimer cet événement"}
            </button>
            {confirmingDelete && !deleting && (
              <button
                onClick={() => setConfirmingDelete(false)}
                style={{
                  width: "100%",
                  background: "none",
                  border: "none",
                  color: colors.muted,
                  fontSize: 11.5,
                  padding: 6,
                  cursor: "pointer"
                }}
              >
                Annuler
              </button>
            )}
            {deleteMsg && <p style={{ fontSize: 11.5, color: colors.muted, marginTop: 4 }}>{deleteMsg}</p>}
          </div>
        )}

        {selectedEventId && (
          <div
            style={{
              background: colors.surface,
              border: `1px solid ${colors.border}`,
              borderRadius: 12,
              padding: 12,
              marginBottom: 14
            }}
          >
            <div style={{ fontSize: 12.5, fontWeight: 700, marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}>
              <Copy size={13} /> Dupliquer cet événement à une nouvelle date
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <input
                type="datetime-local"
                value={duplicateDate}
                onChange={(e) => setDuplicateDate(e.target.value)}
                style={{
                  flex: 1,
                  background: colors.bg,
                  border: `1px solid ${colors.border}`,
                  borderRadius: 10,
                  padding: "8px 10px",
                  fontSize: 12.5,
                  color: colors.ink,
                  boxSizing: "border-box"
                }}
              />
              <button
                onClick={handleDuplicate}
                disabled={duplicating}
                style={{
                  background: colors.blue,
                  border: "none",
                  color: "#fff",
                  borderRadius: 10,
                  padding: "0 14px",
                  fontSize: 12.5,
                  fontWeight: 700,
                  cursor: "pointer",
                  whiteSpace: "nowrap"
                }}
              >
                {duplicating ? "…" : "Dupliquer"}
              </button>
            </div>
            {duplicateMsg && <p style={{ fontSize: 11.5, color: colors.muted, marginTop: 8 }}>{duplicateMsg}</p>}
          </div>
        )}

        {guestsError && <p style={{ color: colors.red, fontSize: 12, marginBottom: 10 }}>{guestsError}</p>}
        {loadingGuests && <p style={{ color: colors.muted, fontSize: 13 }}>Chargement…</p>}

        {guestState && members && (
          <div>
            <p style={{ fontSize: 11.5, color: colors.muted, marginBottom: 10 }}>
              Coche « Inviter » pour ajouter quelqu'un à la liste des invités (utile pour un événement privé), ou « Bloquer » pour lui interdire cet événement précis.
            </p>
            {members.map((m) => {
              const isInvited = guestState.invited.includes(m.id);
              const isBlocked = guestState.blocked.includes(m.id);
              return (
                <div
                  key={m.id}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    background: colors.surface,
                    border: `1px solid ${colors.border}`,
                    borderRadius: 12,
                    padding: "10px 12px",
                    marginBottom: 8,
                    gap: 8
                  }}
                >
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {m.name || m.email}
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                    <button
                      onClick={() => toggleGuestAction("set-invite", m.id, isInvited)}
                      disabled={guestToggling === m.id + "set-invite"}
                      style={{
                        background: isInvited ? "rgba(107,124,79,0.15)" : "none",
                        border: `1px solid ${isInvited ? colors.olive : colors.border}`,
                        color: isInvited ? colors.olive : colors.muted,
                        borderRadius: 20,
                        padding: "5px 10px",
                        fontSize: 11,
                        fontWeight: 700,
                        cursor: "pointer",
                        whiteSpace: "nowrap"
                      }}
                    >
                      <UserCheck size={11} style={{ verticalAlign: "middle", marginRight: 4 }} />
                      {isInvited ? "Invité" : "Inviter"}
                    </button>
                    <button
                      onClick={() => toggleGuestAction("set-block", m.id, isBlocked)}
                      disabled={guestToggling === m.id + "set-block"}
                      style={{
                        background: isBlocked ? "rgba(214,67,42,0.12)" : "none",
                        border: `1px solid ${isBlocked ? colors.red : colors.border}`,
                        color: isBlocked ? colors.red : colors.muted,
                        borderRadius: 20,
                        padding: "5px 10px",
                        fontSize: 11,
                        fontWeight: 700,
                        cursor: "pointer",
                        whiteSpace: "nowrap"
                      }}
                    >
                      <Ban size={11} style={{ verticalAlign: "middle", marginRight: 4 }} />
                      {isBlocked ? "Bloqué" : "Bloquer"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
</>
)}

      {show("autres") && <AdminExternalImports adminSecret={adminSecret} events={allEvents} />}

      {show("nouveautes") && <AdminUpdates adminSecret={adminSecret} />}

{show("lieux") && (
<>
      <AdminVenues adminSecret={adminSecret} />

      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: fonts.display, fontSize: 16, margin: "0 0 10px", display: "flex", alignItems: "center", gap: 6 }}>
          <BarChart3 size={16} color={colors.orange} /> Traçabilité par lieu
        </h2>

        {venueStats === null ? (
          <button
            onClick={loadVenueStats}
            disabled={loadingVenueStats}
            style={{
              width: "100%",
              background: "none",
              border: `1px solid ${colors.border}`,
              color: colors.ink,
              borderRadius: 12,
              padding: 12,
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer"
            }}
          >
            {loadingVenueStats ? "Chargement…" : "Afficher la traçabilité par lieu"}
          </button>
        ) : venueStats.length === 0 ? (
          <p style={{ fontSize: 12.5, color: colors.muted }}>Aucun lieu enregistré pour l'instant.</p>
        ) : (
          venueStats.map((v) => (
            <div
              key={v.id}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                background: colors.surface,
                border: `1px solid ${colors.border}`,
                borderRadius: 12,
                padding: "10px 12px",
                marginBottom: 8
              }}
            >
              <div style={{ fontSize: 13, fontWeight: 600 }}>{v.name}</div>
              <div style={{ fontSize: 11.5, color: colors.muted, textAlign: "right" }}>
                {v.eventsCount} événement{v.eventsCount > 1 ? "s" : ""} · {v.registrationsCount} inscription{v.registrationsCount > 1 ? "s" : ""}
              </div>
            </div>
          ))
        )}
        {venueStatsError && <p style={{ color: colors.red, fontSize: 12, marginTop: 8 }}>{venueStatsError}</p>}
      </div>
</>
)}

{show("propositions") && (
<>
      <h2 style={{ fontFamily: fonts.display, fontSize: 16, margin: "0 0 10px" }}>Co-organisateurs</h2>
      <p style={{ fontSize: 13, color: colors.muted, marginBottom: 20 }}>
        Valide les demandes pour qu'une personne puisse créer ses propres soirées sous Spritz Connection.
      </p>

      {loadingRequests && <p style={{ color: colors.muted, fontSize: 13 }}>Chargement…</p>}
      {requestsError && <p style={{ color: colors.red, fontSize: 12, marginBottom: 10 }}>{requestsError}</p>}
      {!loadingRequests && requests.length === 0 && (
        <p style={{ fontSize: 12.5, color: colors.muted }}>Aucune demande en attente pour l'instant.</p>
      )}

      {requests.map((r) => (
        <div key={r.id} style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderRadius: 14, padding: 14, marginBottom: 12 }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{r.name}</div>
          <div style={{ fontSize: 13, color: colors.muted, marginBottom: 12 }}>{r.note}</div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              disabled={moderatingRequest === r.id}
              onClick={() => moderateRequest(r.id, "approved")}
              style={{ flex: 1, background: colors.olive, border: "none", color: colors.ink, borderRadius: 10, padding: 8, fontWeight: 700, cursor: "pointer" }}
            >
              <Check size={14} style={{ verticalAlign: "middle", marginRight: 6 }} /> Valider
            </button>
            <button
              disabled={moderatingRequest === r.id}
              onClick={() => moderateRequest(r.id, "rejected")}
              style={{ flex: 1, background: "none", border: `1px solid ${colors.border}`, color: colors.ink, borderRadius: 10, padding: 8, cursor: "pointer" }}
            >
              <X size={14} style={{ verticalAlign: "middle", marginRight: 6 }} /> Refuser
            </button>
          </div>
        </div>
      ))}
</>
)}
    </>
  );

  if (isDesktop) {
    return (
      <AdminDesktopShell
        section={section}
        onSection={setSection}
        controls={controls}
        counts={{ propositions: pendingEvents.length + requests.length }}
      >
        {section === "accueil" ? (
          <AdminDashboard
            events={allEvents}
            pendingCount={pendingEvents.length + requests.length}
            onOpenEvent={(id) => {
              setSection("soirees");
              loadGuests(id);
            }}
            onSection={setSection}
          />
        ) : (
          sections
        )}
      </AdminDesktopShell>
    );
  }

  return (
    <div style={{ padding: "0 20px 40px" }}>
      {controls}
      {sections}
    </div>
  );
}
